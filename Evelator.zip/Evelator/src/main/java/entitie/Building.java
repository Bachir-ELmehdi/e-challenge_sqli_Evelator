package entitie;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.stream.Collectors;

import Factory.FactoryEvelator;
import StateEvelator.DOWN;
import StateEvelator.STOP;
import StateEvelator.UP;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Evelator
 * Package =====> entitie
 * Date    =====> 20 nov. 2019 
 */
public class Building {
	int nombreEtage;
	private FactoryEvelator fact = new  FactoryEvelator();
	
	private LinkedList<Evelator> Evelators;
	/**
	 * 
	 */
	public Building() {
		// TODO Auto-generated constructor stub
	}
	
	public void  addevelator(Evelator ev) {
		Evelators.add(ev);
	}
	public Building(int nombre, String ...evelators) {
		Evelators = new LinkedList<Evelator>();
		nombreEtage = nombre;
		Arrays.stream(evelators)
		.forEach(evelator->addevelator(fact.getInstance(evelator.substring(0,3), Integer.parseInt(evelator.substring(4, 5)))	    
		));	
	}
	
	public  String requestElevator() {
		String re = null;
		LinkedList<Evelator> up = recuperer("UP");
		LinkedList<Evelator> down= recuperer("DOWN");
		LinkedList<Evelator> stop = recuperer("STOP");
     System.out.println(stop.size());
		if(down.size()+stop.size() ==0) {
            re = lePluUp(up).getId();
		}
		
		else	if(stop.size()==0 && (up.size()==down.size()))
			re =     down.get(0).getId();
		else if(stop.size()> 1)
			re = stop.get(0).getEtage() > stop.get(1).getEtage()  ? stop.get(1).getId() : stop.get(0).getId();
		else if(up.size() ==1 && down.size()==0)
			re = stop.size() >0 ? stop.get(0).getId()  :  up.get(0).getId();
		else if(stop.size()>0 && down.size() > 0)
		  re  = stop.get(0).getEtage()< down.get(0).getEtage() ? stop.get(0).getId() : down.get(0).getId();
		return re;
	}
	
	public Evelator lePluUp(LinkedList<Evelator> list) {
		Evelator ev = list.get(0);
		for(Evelator e: this.Evelators) {
			if(e.getEtage()>ev.getEtage())
				ev=e;
		}
		return ev;
		
	}
	
	public  String requestElevator(int request) {
		String re = null;
		LinkedList<Evelator> up = recuperer("UP");
		LinkedList<Evelator> down= recuperer("DOWN");
		LinkedList<Evelator> stop = recuperer("STOP");
		if(stop.size() > 1 &&  down.size()+up.size() ==0)
	    	re= Math.abs(stop.get(0).getEtage() -5) > Math.abs(stop.get(1).getEtage() -5) ? stop.get(1).getId() : stop.get(0).getId();
	return re ;
	}
	
	public LinkedList<Evelator> recuperer(String State){
		LinkedList<Evelator> resulta = new LinkedList<Evelator>();
		
		
		if(State.equals("DOWN")) {
			resulta = (LinkedList<Evelator>) Evelators.stream().
					        filter(x->(x.getState() instanceof DOWN))
					        .collect(Collectors.toCollection(LinkedList::new)).clone();				        
			}if(State.equals("UP")) {
			 resulta = new LinkedList<Evelator>();
		resulta = (LinkedList<Evelator>) Evelators.stream().
				        filter(x->(x.getState() instanceof UP))
				        .collect(Collectors.toCollection(LinkedList::new)).clone();				        
		}
		if(State.equals("STOP")) {
			
			resulta = (LinkedList<Evelator>) Evelators.stream().
					        filter(x->(x.getState() instanceof STOP))
					        .collect(Collectors.toCollection(LinkedList::new)).clone();				        
			}
				  return resulta;     
	}
	
	/**
	 * @return the evelators
	 */
	public LinkedList<Evelator> getEvelators() {
		return Evelators;
	}
	
	
	public void move(String id,String state ) {
		for(Evelator e : this.Evelators) {
			if(e.getId().equals(id)) {
				if(state.equals("UP"))
			    	e.UP();
			   if(state.equals("DOWN"))
				   e.DOWN();
			}
		}
		
		///--redifinito=ion du clone 
		
    		
	}
	
	public void affiche(){
		for(Evelator e : Evelators) {
			System.out.println(e);
			System.out.println("\n");
		}
	}
	
	
	public Object clone() throws CloneNotSupportedException {
		LinkedList<Evelator> copy = new LinkedList<Evelator>();
		// TODO Auto-generated method stub
		for(Evelator ev: this.Evelators) {
			copy.add(ev);
		}
		return copy;
	}

}
