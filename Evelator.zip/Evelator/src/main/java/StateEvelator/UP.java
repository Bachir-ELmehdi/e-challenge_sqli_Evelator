package StateEvelator;

import Exception.ExceptionEvelator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Evelator
 * Package =====> StateEvelator
 * Date    =====> 20 nov. 2019 
 */
public class UP  extends StateEvelator
{
    public UP() {
    	
    }
	 
	
	@Override
	public void UP() {
		// TODO Auto-generated method stub
		throw new ExceptionEvelator();

	}

	@Override
	public void Down() {
		// TODO Auto-generated method stub
		evelator.setState(new DOWN());
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

}
