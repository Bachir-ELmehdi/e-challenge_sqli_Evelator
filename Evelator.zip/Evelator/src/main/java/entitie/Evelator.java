package entitie;

import StateEvelator.STOP;
import StateEvelator.StateEvelator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Evelator
 * Package =====> entitie
 * Date    =====> 20 nov. 2019 
 */
public class Evelator {
	private String id;
	private int etage;
	private StateEvelator state= new STOP();
	
	public Evelator(String id, int  etage) {
		this.id = id;
		this.etage = etage;
		state.setEvelator(this);
	}
	
	/**
	 * @param state the state to set
	 */
	public void setState(StateEvelator state) {
		this.state = state;
		state.setEvelator(this);
	}
	
	public void UP() {		
		state.setEvelator(this);

		state.UP();
	}
	public void DOWN() {
		state.Down();
		state.setEvelator(this);
	}
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	public Evelator() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @return the etage
	 */
	public int getEtage() {
		return etage;
	}
	/**
	 * @return the state
	 */
	public StateEvelator getState() {
		return state;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Etage: "+etage+"ID : "+id;
	}

}
