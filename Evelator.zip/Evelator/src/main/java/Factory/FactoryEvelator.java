package Factory;

import entitie.Evelator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Evelator
 * Package =====> Factory
 * Date    =====> 20 nov. 2019 
 */
public class FactoryEvelator {
	
	public Evelator getInstance(String id, int  etage) {
		return new Evelator(id, etage);
	}

}
