package StateEvelator;

import entitie.Evelator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Evelator
 * Package =====> StateEvelator
 * Date    =====> 20 nov. 2019 
 */
public abstract class StateEvelator {
	
	protected  Evelator evelator;
	   public abstract  void UP();
	   public  abstract void Down();
	   public  abstract String toString();
	   
	   /**
	 * @param evelator the evelator to set
	 */
	public void setEvelator(Evelator evelator) {
		this.evelator = evelator;
	}
	   
	/**
	 * @return the evelator
	 */
	public Evelator getEvelator() {
		return evelator;
	}

}
