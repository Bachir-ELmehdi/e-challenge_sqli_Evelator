package StateEvelator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Evelator
 * Package =====> StateEvelator
 * Date    =====> 20 nov. 2019 
 */
public class STOP extends StateEvelator {
	
	/**
	 * 
	 */
	public STOP() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void UP() {
		// TODO Auto-generated method stub
		evelator.setState(new UP());
	}

	@Override
	public void Down() {
		// TODO Auto-generated method stub
		evelator.setState(new DOWN());
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

}
