package Exception;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> Evelator
 * Package =====> Exception
 * Date    =====> 20 nov. 2019 
 */
public class ExceptionEvelator extends RuntimeException {

}
